plugins {
    id("com.android.application")
}

android {
    namespace = "com.wildriftmetalite"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.wildriftmetalite"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core:1.16.0")
}

// This project is Java-only. Some AndroidX dependencies can bring the legacy
// Kotlin JDK7/JDK8 compatibility artifacts alongside kotlin-stdlib, which
// causes duplicate-class errors with modern Android Gradle Plugin builds.
configurations.configureEach {
    exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk7")
    exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk8")
}
