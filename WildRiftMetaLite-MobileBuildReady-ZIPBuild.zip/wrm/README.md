# WildRiftMetaLite — Mobile Build Ready

โปรเจกต์ Android ที่เตรียมไว้สำหรับแก้ไข/Build จากมือถือผ่าน GitHub Codespaces หรือ GitHub Actions

## Build แบบ Cloud
1. สร้าง GitHub Repository ใหม่
2. แตก ZIP แล้วอัปโหลด "เนื้อหาข้างในโฟลเดอร์นี้" เข้า repository
3. เปิด Codespaces หรือใช้ GitHub Actions workflow
4. Build ด้วย Gradle 8.11.1 + JDK 17

คำสั่ง:
```bash
gradle assembleDebug
```

APK:
```text
app/build/outputs/apk/debug/app-debug.apk
```

## เปลี่ยนเว็บที่แอปเปิด
แก้ไฟล์:
```text
app/src/main/java/com/wildriftmetalite/MainActivity.java
```

ตรง:
```java
webView.loadUrl("https://www.google.com/search?q=Wild+Rift+meta");
```

## หมายเหตุ
รุ่นนี้เป็นฐาน Mobile Build Ready: WebView + Android Back + JavaScript/DOM storage + portrait mode + GitHub Actions
ยังไม่ได้ฝังข้อมูลแชมเปี้ยน/ไอเท็มจำนวนมาก เพื่อให้ APK เบาและแก้ไขง่าย
